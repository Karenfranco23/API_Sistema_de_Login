-- --------------------------------------------------------
-- Servidor:                     127.0.0.1
-- Versão do servidor:           8.0.30 - MySQL Community Server - GPL
-- OS do Servidor:               Win64
-- HeidiSQL Versão:              12.1.0.6537
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


-- Copiando estrutura do banco de dados para database_prisma
CREATE DATABASE IF NOT EXISTS `database_prisma` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `database_prisma`;

-- Copiando estrutura para tabela database_prisma.post
CREATE TABLE IF NOT EXISTS `post` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `published` tinyint(1) DEFAULT '0',
  `authorId` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `Post_authorId_fkey` (`authorId`),
  CONSTRAINT `Post_authorId_fkey` FOREIGN KEY (`authorId`) REFERENCES `user` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Copiando dados para a tabela database_prisma.post: ~0 rows (aproximadamente)

-- Copiando estrutura para tabela database_prisma.user
CREATE TABLE IF NOT EXISTS `user` (
  `id` int NOT NULL AUTO_INCREMENT,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `role` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `User_email_key` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Copiando dados para a tabela database_prisma.user: ~9 rows (aproximadamente)
INSERT INTO `user` (`id`, `email`, `password`, `name`, `role`) VALUES
	(1, 'matheus@gmail.com', '$2b$10$ESk4POHMU5WsTErqHkPMCu4hVSLojynqwN0MyJAQrk5161kEYJcs.', 'Matheus Fernandes', 'admin'),
	(2, 'karen@gmail.com', '$2b$10$uWYyoZcIrz3pjkkXqKwKVOKrWF6pCjjL4uqO/nfKtuokCVIAPZO0u', 'Karen Franco', 'user'),
	(3, 'marcos@gmail.com', '$2b$10$TrBg8yHgnzTTEMiR7pqNguQ3Mz4KS.ybVgnQohUweAWbd6pvSXkOq', 'Marcos Franco', 'user'),
	(5, 'charles@gmail.com', '$2b$10$l7CnGyzc8BtjHT.P/OaqCeKXjfvVlVN6kRqQipNMRtg4.IufRp.Qu', 'Charles Franco', 'user'),
	(6, 'lucas@gmail.com', '$2b$10$H3RGJJw.WtHsOzGjJfPS6.43DyqDE3k0OmvXeG9STkoE4U3K9v0K6', 'Lucas Franco', 'user'),
	(8, 'pedro@gmail.com', '$2b$10$axSOfKDOBpFUaW8zMn/5yufsrl6toaOddIwqtRgUhCXWt9udTJJNy', 'Pedro Franco', 'user'),
	(9, 'rafael@gmail.com', '$2b$10$fwOE30jdAgPZj/kH5svF3ufKCyWTfCi7K4yiUFSO4iEZZLDadr6rq', 'Rafael Franco', 'user'),
	(10, 'miguel@gmail.com', '$2b$10$BiPQ88fLMMagfCWGqD4gB.V/hguUrNxbtXzuGXC4uLmMZrbjrKm1S', 'Miguel Franco', 'user'),
	(11, 'marta@gmail.com', '$2b$10$ueqp5t1/e7WhTfXctmuQjubzdMyaurVkM3etSwjYn9P2FQE1ldz86', 'Marta Franco', 'admin');

-- Copiando estrutura para tabela database_prisma._prisma_migrations
CREATE TABLE IF NOT EXISTS `_prisma_migrations` (
  `id` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `checksum` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `finished_at` datetime(3) DEFAULT NULL,
  `migration_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `logs` text COLLATE utf8mb4_unicode_ci,
  `rolled_back_at` datetime(3) DEFAULT NULL,
  `started_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `applied_steps_count` int unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Copiando dados para a tabela database_prisma._prisma_migrations: ~1 rows (aproximadamente)
INSERT INTO `_prisma_migrations` (`id`, `checksum`, `finished_at`, `migration_name`, `logs`, `rolled_back_at`, `started_at`, `applied_steps_count`) VALUES
	('ceb09cf1-edef-46a4-85be-0176f114d6cf', 'ba002b57a63919d35b8320a2cd3ca283ccf625376acb66e90c8afb3f28ce907d', '2023-01-05 00:19:15.075', '20230105001818_init', NULL, NULL, '2023-01-05 00:19:15.009', 1);

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
